import { execSync, spawnSync } from "child_process";
import { existsSync, readFileSync, writeFileSync } from "fs";
import { createInterface } from "readline";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const GITHUB_USER = "eli281193-cpu";
const REPO_NAME = "eli-tools";
const ACCOUNT_ID = "88781688ab38b45bcd2b5f513036980a";

// ── helpers ──────────────────────────────────────────────────────────────────

function ask(rl, q) {
  return new Promise(res => rl.question(q, res));
}

function run(cmd, opts = {}) {
  try {
    const result = execSync(cmd, {
      stdio: opts.silent ? "pipe" : "inherit",
      encoding: "utf8",
      cwd: __dirname
    });
    return result;
  } catch (e) {
    if (opts.ignore) return "";
    console.error(`\n❌ נכשל: ${cmd}`);
    process.exit(1);
  }
}

function curl(args, opts = {}) {
  const result = spawnSync("curl", args.split(" ").filter(Boolean), {
    encoding: "utf8",
    cwd: __dirname
  });
  if (opts.parse) {
    try { return JSON.parse(result.stdout); } catch { return null; }
  }
  return result.stdout;
}

// ── main ─────────────────────────────────────────────────────────────────────

async function main() {
  console.log("\n╔══════════════════════════════════════════╗");
  console.log("║   🚀  eli-tools — Deploy Script          ║");
  console.log("╚══════════════════════════════════════════╝\n");

  // ── 1. Git ────────────────────────────────────────────────────────────────
  process.stdout.write("🔍 בודק Git... ");
  try { execSync("git --version", { stdio: "pipe" }); console.log("✅"); }
  catch {
    console.log("❌");
    console.log("\nGit לא מותקן. הורד מ: https://git-scm.com/download/win");
    console.log("לאחר ההתקנה הרץ שוב: node deploy.js\n");
    process.exit(1);
  }

  // ── 2. טוקנים מ-.env ─────────────────────────────────────────────────────
  const envPath = path.join(__dirname, ".env");
  let GITHUB_TOKEN = "", CF_TOKEN = "";

  if (existsSync(envPath)) {
    const lines = readFileSync(envPath, "utf8").split("\n");
    for (const line of lines) {
      const [k, ...rest] = line.split("=");
      const v = rest.join("=").trim();
      if (k === "GITHUB_TOKEN") GITHUB_TOKEN = v;
      if (k === "CF_TOKEN") CF_TOKEN = v;
    }
    if (GITHUB_TOKEN && CF_TOKEN) {
      console.log("🔑 טוקנים נטענו מ-.env ✅\n");
    }
  }

  const rl = createInterface({ input: process.stdin, output: process.stdout });

  if (!GITHUB_TOKEN) {
    console.log("🔑 הכנס את GitHub Token שלך (מתחיל ב-ghp_):");
    GITHUB_TOKEN = (await ask(rl, "   > ")).trim();
  }
  if (!CF_TOKEN) {
    console.log("🔑 הכנס את Cloudflare API Token שלך:");
    CF_TOKEN = (await ask(rl, "   > ")).trim();
  }

  // שמירה ב-.env
  writeFileSync(envPath, `GITHUB_TOKEN=${GITHUB_TOKEN}\nCF_TOKEN=${CF_TOKEN}\n`);
  console.log("\n✅ טוקנים נשמרו ב-.env (לא יעלה ל-GitHub)\n");

  rl.close();

  // ── 3. Git init ───────────────────────────────────────────────────────────
  console.log("📁 מאתחל Git...");
  if (!existsSync(path.join(__dirname, ".git"))) {
    run("git init");
    run("git branch -M main", { ignore: true });
  }
  run(`git remote remove origin`, { ignore: true });
  run(`git remote add origin https://${GITHUB_TOKEN}@github.com/${GITHUB_USER}/${REPO_NAME}.git`);

  // git config
  try { execSync("git config user.email", { stdio: "pipe" }); }
  catch { run(`git config user.email "eli281193@users.noreply.github.com"`); }
  try { execSync("git config user.name", { stdio: "pipe" }); }
  catch { run(`git config user.name "Eli"`); }

  console.log("✅ Git מוכן\n");

  // ── 4. GitHub repo ────────────────────────────────────────────────────────
  console.log("🔍 בודק GitHub repo...");
  const repoCheck = curl(
    `-s -o /dev/null -w %{http_code} -H "Authorization: token ${GITHUB_TOKEN}" https://api.github.com/repos/${GITHUB_USER}/${REPO_NAME}`
  ).trim();

  if (repoCheck === "404") {
    console.log("📦 יוצר repo חדש...");
    curl(
      `-s -X POST -H "Authorization: token ${GITHUB_TOKEN}" -H "Content-Type: application/json" https://api.github.com/user/repos -d {"name":"${REPO_NAME}","private":false,"description":"Eli online tools"}`
    );
    console.log(`✅ Repo נוצר: https://github.com/${GITHUB_USER}/${REPO_NAME}\n`);
  } else {
    console.log(`✅ Repo קיים\n`);
  }

  // ── 5. Commit + Push ──────────────────────────────────────────────────────
  console.log("📤 מעלה קוד ל-GitHub...");
  run("git add .");
  const status = run("git status --porcelain", { silent: true })?.trim();
  if (status) {
    run(`git commit -m "deploy: timer + home page"`);
    const pushResult = spawnSync(
      "git", ["push", "-u", "origin", "main", "--force"],
      { encoding: "utf8", cwd: __dirname, stdio: "inherit" }
    );
    if (pushResult.status !== 0) {
      run("git push -u origin master --force", { ignore: true });
    }
    console.log("✅ קוד עלה ל-GitHub\n");
  } else {
    console.log("✅ אין שינויים חדשים\n");
  }

  // ── 6. Cloudflare Pages deploy ────────────────────────────────────────────
  console.log("☁️  מעלה ל-Cloudflare Pages...");

  // התקנת wrangler אם צריך
  try { execSync("npx wrangler --version", { stdio: "pipe" }); }
  catch {
    console.log("📦 מתקין wrangler (רק פעם ראשונה)...");
    execSync("npm install -g wrangler", { stdio: "inherit" });
  }

  process.env.CLOUDFLARE_API_TOKEN = CF_TOKEN;
  process.env.CLOUDFLARE_ACCOUNT_ID = ACCOUNT_ID;

  const deployResult = spawnSync(
    "npx",
    ["wrangler", "pages", "deploy", ".", "--project-name", REPO_NAME, "--commit-dirty=true"],
    { encoding: "utf8", cwd: __dirname, stdio: "inherit", env: process.env }
  );

  if (deployResult.status !== 0) {
    console.log("\n⚠️  נסיון שני...");
    spawnSync(
      "node_modules/.bin/wrangler",
      ["pages", "deploy", ".", "--project-name", REPO_NAME, "--commit-dirty=true"],
      { encoding: "utf8", cwd: __dirname, stdio: "inherit", env: process.env }
    );
  }

  // ── 7. סיום ───────────────────────────────────────────────────────────────
  console.log("\n╔══════════════════════════════════════════╗");
  console.log("║   ✅  הכל עלה בהצלחה!                    ║");
  console.log("╚══════════════════════════════════════════╝");
  console.log(`\n🌐 האתר:    https://${REPO_NAME}.pages.dev`);
  console.log(`⏱  טיימר:   https://${REPO_NAME}.pages.dev/timer`);
  console.log(`📁 GitHub:  https://github.com/${GITHUB_USER}/${REPO_NAME}\n`);
}

main().catch(e => { console.error("❌", e.message); process.exit(1); });
